import edu.biu.scapi.primitives.dlog.SecretSharing;
import edu.biu.scapi.primitives.dlog.SecretRecovery;
import edu.biu.scapi.primitives.dlog.CryptoPpPolynomialGF2pow8;
import edu.biu.scapi.primitives.dlog.CryptoPpGF2pow8Element;
import edu.biu.scapi.primitives.dlog.FieldElement;
import java.nio.*;
import java.util.*;
import java.security.SecureRandom;
import java.math.BigInteger;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Paths;


class SecretSharingFile
{
static File fileinS;
static int nShares;

	public static void main(String args[]) throws Exception
	{
	try{
		SecretShare();
		SecretRec();
	}
	finally{
         		
	
	}	

}

private static void SecretShare() throws Exception{

	String inputFileName="input", outputFileName="output";
	String fileExt = ".txt";
	String outputFiles[];	
	Scanner scan = new Scanner(System.in);

	FieldElement xPoints[],secret;
	CryptoPpGF2pow8Element shares[];


	int threshold;
	SecretSharing secSharObj;

	//Input files	
	FileInputStream inS = null;
	DataInputStream dataInS = null;
	fileinS = null;
	
	//Output files
	File fileoutS[] = null;
	FileWriter[] fw=null;

	System.out.println("Enter t & n: ");

	//Threshold & number of shares/participants

	threshold=scan.nextInt();		
	nShares=scan.nextInt();
	scan.nextLine(); 

	outputFiles=new String[nShares];

	fileinS = new File(inputFileName + fileExt);		
	inS = new FileInputStream(fileinS);
	dataInS = new DataInputStream(inS);
		
	fileoutS = new File[nShares];
	
	fw = new FileWriter[nShares];
			
	for(int i=0;i<nShares;i++){
				
		outputFiles[i] =  outputFileName + Integer.toString(i+1) + fileExt;		
		fileoutS[i] = new File(outputFiles[i]);
		
		fw[i] = new FileWriter(outputFiles[i],true);

	}
	
	shares = new CryptoPpGF2pow8Element[nShares];
	xPoints = new CryptoPpGF2pow8Element[nShares];

	for(int i=0;i<nShares;i++)
		xPoints[i] = new CryptoPpGF2pow8Element((byte)(i+1));

	secret = new CryptoPpGF2pow8Element((byte)0);
	secSharObj = new SecretSharing(threshold,secret);

	secSharObj.setPoints(xPoints);

	long len = fileinS.length();
	for(long j = 0; j < len; j++){
		secret = new CryptoPpGF2pow8Element(dataInS.readByte());
		secSharObj.setSecret(secret);
		shares = (CryptoPpGF2pow8Element [])secSharObj.splitShares();
		for(int i=0;i<nShares;i++)
		{
			fw[i].write(String.valueOf(shares[i].getElementValue())+" ");
		}

	}

		


	System.out.println("Shares generated are..");
	for(int i=0;i<nShares;i++)				
		System.out.println(outputFiles[i]);		

        for (int i=0;i<nShares ; i++ ){
   	 		fw[i].close();
      	}

}
	
private static void SecretRec() throws Exception{

	 //Secret Recovery
	 //Input file
	 String outputFileName="output";
	 String fileExt = ".txt";

	 File fileinR[] = null;	
	
	 //Output files
	 FileOutputStream outR = null;
	 DataOutputStream dataOutR = null;
	 File fileoutR = null;

	 FileReader fr [] = null;

	SecretRecovery secRecObj;
	Scanner scan = new Scanner(System.in);
	FieldElement xPointsToRecoverSecret[],sharesToRecoverSecret[];

	System.out.println("enter atleast shares. Share numbers (space-separated) to get back the secret");

	String secretRecoveryFileNumbers =scan.nextLine();		
	String secretRecoveryFileNumbersArray[]=secretRecoveryFileNumbers.split(" ");
	
	fileinR = new File[secretRecoveryFileNumbersArray.length];

	fr = new FileReader[secretRecoveryFileNumbersArray.length];

	String filn = "final" +outputFileName + fileExt;
	fileoutR = new File(filn);
	outR = new FileOutputStream(fileoutR);
	dataOutR = new DataOutputStream(outR);

	String outputfiles[] = new String[secretRecoveryFileNumbersArray.length];

	for(int i=0;i<secretRecoveryFileNumbersArray.length;i++){
		outputfiles[i] = outputFileName + secretRecoveryFileNumbersArray[i] + fileExt;
		fileinR[i] = new File(outputfiles[i]);

		fr[i] = new FileReader(fileinR[i]);
	}	

	int noOfFiles = secretRecoveryFileNumbersArray.length;


	byte byteMatrix[][] = new byte[noOfFiles][];


	//read all files and get byte[][]
	for(int i=0;i<noOfFiles;i++){

		byteMatrix[i] = new byte[(int)fileinR[i].length()];

		String str="";
		int c=0;
		String tokens[] = null;
		int file_no = Integer.parseInt(secretRecoveryFileNumbersArray[i]);
		while((c=fr[i].read())!=-1){
			str+=(char)c;
		}
		tokens=str.split(" ");

		for(int j=0;j<tokens.length;j++)
		{
			byte b = Byte.valueOf(tokens[j]);
			byteMatrix[i][j]=b;
		}
	}
//printing byteMatrix
	/*for(int i=0;i<noOfFiles;i++){
		for(int j=0;j<filesize;j++){
			System.out.print(byteMatrix[i][j]+" ");
		}
		System.out.println();

	}	*/


	for(long l=0;l<fileinS.length() ;l++){


	xPointsToRecoverSecret = new CryptoPpGF2pow8Element[noOfFiles];
	sharesToRecoverSecret = new CryptoPpGF2pow8Element[noOfFiles];
	for(int i=0;i<noOfFiles;i++){
		xPointsToRecoverSecret[i] = new CryptoPpGF2pow8Element((byte)Integer.parseInt(secretRecoveryFileNumbersArray[i]));
		sharesToRecoverSecret[i] = new CryptoPpGF2pow8Element(byteMatrix[i][(int)l]);
	}
	secRecObj = new SecretRecovery(noOfFiles,xPointsToRecoverSecret,sharesToRecoverSecret);
	CryptoPpGF2pow8Element result =(CryptoPpGF2pow8Element)secRecObj.recoverSecret();
	dataOutR.write(result.getElementValue());

	}


	System.out.println("Secret recovered is :"+filn);
}

}
