import java.nio.*;


import java.nio.file.Files;
import java.nio.file.Paths;

import java.util.List;
import java.util.LinkedList;
import java.util.Map;
import java.util.Iterator;
import java.util.HashMap;
import edu.biu.scapi.comm.Channel;
import edu.biu.scapi.comm.multiPartyComm.MultipartyCommunicationSetup;
import edu.biu.scapi.comm.multiPartyComm.SocketMultipartyCommunicationSetup;
import edu.biu.scapi.comm.twoPartyComm.LoadSocketParties;
import edu.biu.scapi.comm.twoPartyComm.PartyData;
import edu.biu.scapi.comm.Party;
import java.util.concurrent.TimeoutException;
import edu.biu.scapi.comm.twoPartyComm.SocketPartyData;
import java.net.InetAddress;

import edu.biu.scapi.primitives.dlog.SecretSharing;
import edu.biu.scapi.primitives.dlog.SecretRecovery;
import edu.biu.scapi.primitives.dlog.CryptoPpPolynomialGF2pow8;
import edu.biu.scapi.primitives.dlog.CryptoPpGF2pow8Element;
import edu.biu.scapi.primitives.dlog.FieldElement;


import java.io.*;
import java.util.*;

class Dealer
{
static File fileinS;
static int nShares;
static File shares[];
static String outputFileName="output";
static String fileExt = ".txt";
	public static void main(String args[]) throws Exception
	{
		try{
				//generate Shares
				shares = SecretShare();
				

				List<PartyData> list = new LinkedList<PartyData>();
				list.add(new SocketPartyData(InetAddress.getByName("127.0.0.1"),8000));
			    list.add(new SocketPartyData(InetAddress.getByName("127.0.0.1"),8001));
			    list.add(new SocketPartyData(InetAddress.getByName("127.0.0.1"),8002));
			   list.add(new SocketPartyData(InetAddress.getByName("127.0.0.1"),8003));

		    	sendData(list);
				

			}
			catch(Exception e)
			{
				System.out.println(e);
			}
			finally
			{

			}
			
				
			
		}
		

 static Map<PartyData, Map<String, Channel>> setupComm(List<PartyData> listOfParties) throws TimeoutException
	 {

        //Create the communication setup class.
        MultipartyCommunicationSetup commSetup = new SocketMultipartyCommunicationSetup(listOfParties);

        //Request two chanels between me and each other party.
        HashMap<PartyData, Object> connectionsPerParty = new HashMap<PartyData, Object>();
        int i=1;
        while(i<=listOfParties.size()-1)
        {
        	connectionsPerParty.put(listOfParties.get(i), 1);	
        	i++;
        }
        
        //Call the prepareForCommunication function to establish the connections within 2000000 milliseconds.
        Map<PartyData, Map<String, Channel>> connections = commSetup.prepareForCommunication(connectionsPerParty, 2000000);

        //Returns the channels to the other parties.
        return connections;
    }


     private static void sendData(List<PartyData> list)
    {
		    	
				byte[] array;

			try
			{	
       			Map<PartyData, Map<String, Channel>> map = setupComm(list);
       			

	            Iterator iter = map.entrySet().iterator();
	            while(iter.hasNext())
	            {
	                Map.Entry entry = (Map.Entry)iter.next();
	                PartyData party = (PartyData)entry.getKey();
	                Channel channel = (Channel)((Map<String, Channel>)entry.getValue()).values().iterator().next();
					
					int port_no = ((SocketPartyData)party).getPort();
	                int i = port_no % 10;
	            	array = fileToByteArray(shares[i-1]);
	                String filename=outputFileName+i+fileExt;
        			System.out.println("Sending File "+filename);
					channel.send(filename);
					channel.send(array);
					channel.close();        

	              
	            }
	        
	        }catch(Exception e)
			{
				System.out.println(e);
			}
    }


private static File[] SecretShare() throws Exception
	{

		String inputFileName="input";
		
		String outputFiles[];	
		Scanner scan = new Scanner(System.in);

		FieldElement xPoints[],secret;
		CryptoPpGF2pow8Element shares[];


		int threshold;
		SecretSharing secSharObj;

		//Input files	
		FileInputStream inS = null;
		DataInputStream dataInS = null;
		fileinS = null;
		
		//Output files
		FileOutputStream outS[] = null;
		DataOutputStream dataOutS[] = null;
		File fileoutS[] = null;

		System.out.println("Enter t & n: (Temporarily enter t=2 and n=3)");

		//Threshold & number of shares/participants

		threshold=scan.nextInt();		
		nShares=scan.nextInt();
		scan.nextLine(); 

		outputFiles=new String[nShares];

		fileinS = new File(inputFileName + fileExt);		
		inS = new FileInputStream(fileinS);
		dataInS = new DataInputStream(inS);
			
		fileoutS = new File[nShares];
		outS = new FileOutputStream[nShares];
		dataOutS = new DataOutputStream[nShares];
		
		for(int i=0;i<nShares;i++){
				
			outputFiles[i] =  outputFileName + Integer.toString(i+1) + fileExt;		
			fileoutS[i] = new File(outputFiles[i]);
			outS[i] = new FileOutputStream(fileoutS[i]);
			dataOutS[i] = new DataOutputStream(outS[i]);

		}

		
		shares = new CryptoPpGF2pow8Element[nShares];
		xPoints = new CryptoPpGF2pow8Element[nShares];

		for(int i=0;i<nShares;i++)
			xPoints[i] = new CryptoPpGF2pow8Element((byte)(i+1));

		secret = new CryptoPpGF2pow8Element((byte)0);
		secSharObj = new SecretSharing(threshold,secret);

		secSharObj.setPoints(xPoints);

		long len = fileinS.length();
		for(long j = 0; j < len; j++){
		secret = new CryptoPpGF2pow8Element(dataInS.readByte());
		secSharObj.setSecret(secret);
		shares = (CryptoPpGF2pow8Element [])secSharObj.splitShares();
		for(int i=0;i<nShares;i++)
			dataOutS[i].write((int)((CryptoPpGF2pow8Element)shares[i]).getElementValue());
		}

			


		System.out.println("Shares generated are..");
	for(int i=0;i<nShares;i++)				
		System.out.println(outputFiles[i]);		

        for (int i=0;i<nShares ; i++ ){
		if(dataOutS[i] != null){
   	 		dataOutS[i].close();
            	}	 	
      	}

	return fileoutS;
	}

private static byte [] fileToByteArray(File file)
    {
    	byte[] array = new byte[(int)file.length()];
    	try{
   		    FileInputStream fis = new FileInputStream(file);
            
            fis.read(array);
            fis.close();
            

    	}catch(Exception e)
    	{
    		System.out.println(e);
    	}
    	return array;
        
    }

    private static void byteArrayToFile(byte [] array, String filename)
    {
    	try{
    		File file = new File(filename);
	        FileOutputStream fos = new FileOutputStream(file);
	        fos.write(array);
	        fos.close();	

    	}catch(Exception e)
    	{
    		System.out.println(e);
    	}
        
        

    }


		
}