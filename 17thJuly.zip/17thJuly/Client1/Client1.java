import java.util.List;
import java.util.LinkedList;
import java.util.Map;
import java.util.Iterator;
import java.util.HashMap;
import edu.biu.scapi.comm.Channel;
import edu.biu.scapi.comm.multiPartyComm.MultipartyCommunicationSetup;
import edu.biu.scapi.comm.multiPartyComm.SocketMultipartyCommunicationSetup;
import edu.biu.scapi.comm.twoPartyComm.LoadSocketParties;
import edu.biu.scapi.comm.twoPartyComm.PartyData;
import edu.biu.scapi.comm.Party;
import java.util.concurrent.TimeoutException;
import edu.biu.scapi.comm.twoPartyComm.SocketPartyData;
import java.net.InetAddress;
import java.io.*;
import java.util.*;

import edu.biu.scapi.primitives.dlog.SecretSharing;
import edu.biu.scapi.primitives.dlog.SecretRecovery;
import edu.biu.scapi.primitives.dlog.CryptoPpPolynomialGF2pow8;
import edu.biu.scapi.primitives.dlog.CryptoPpGF2pow8Element;
import edu.biu.scapi.primitives.dlog.FieldElement;
import java.security.SecureRandom;
import java.math.BigInteger;




class Client1{
static ArrayList<String> recoverFiles;
static int totalFiles=0;

	public static void main(String ar[]) throws Exception
	{
		recoverFiles = new ArrayList<String>();

		List<PartyData> list = new LinkedList<PartyData>();
		list.add(new SocketPartyData(InetAddress.getByName("127.0.0.1"),8001));
		list.add(new SocketPartyData(InetAddress.getByName("127.0.0.1"),8000));
		list.add(new SocketPartyData(InetAddress.getByName("127.0.0.1"),8002));
		list.add(new SocketPartyData(InetAddress.getByName("127.0.0.1"),8003));

		receiveData(list);
		if(totalFiles>0)
			SecretRec(recoverFiles.size());
			
	}


	static Map<PartyData, Map<String, Channel>> makeConnections(List<PartyData> list) throws TimeoutException
	{
		 //Create the communication setup class.
	    MultipartyCommunicationSetup commSetup = new SocketMultipartyCommunicationSetup(list);

	    //Request two chanels between me and each other party.
	    HashMap<PartyData, Object> connectionsPerParty = new HashMap<PartyData, Object>();

	    for(int i=1;i<list.size();i++)
			connectionsPerParty.put(list.get(i), 1);
	    
	    //Call the prepareForCommunication function to establish the connections within 2000000 milliseconds.
	    Map<PartyData, Map<String, Channel>> connections = commSetup.prepareForCommunication(connectionsPerParty, 2000000);

	    //Returns the channels to the other parties.
	    return connections;

	} 

	    private static byte [] fileToByteArray(File file)
    {
        byte[] array = new byte[(int)file.length()];
        try{
            FileInputStream fis = new FileInputStream(file);
            
            fis.read(array);
            fis.close();
            

        }
        catch(EOFException e) {
        //eof - no error in this case
        }
        catch(Exception e)
        {
            System.out.println(e);
        }
        return array;
        
    }

    private static void byteArrayToFile(byte [] array, String filename)
    {
        try{
            File file = new File(filename);
            FileOutputStream fos = new FileOutputStream(file);
            fos.write(array);
            fos.close();    

        }
        catch(EOFException e) {
        //eof - no error in this case
        }
        catch(Exception e)
        {
            System.out.println(e);
        }
        
        

    }



	private static void receiveData(List<PartyData> list)
	{
		try
		{

			Scanner scan = new Scanner(System.in);
			Map<PartyData,Map<String,Channel>> map = makeConnections(list);
			boolean isReceived=false;
			String file_name="";
			byte[] array=null;
			while(true)
			{
				Iterator iter = map.entrySet().iterator();	
				while(iter.hasNext())
				{
					Map.Entry entry = (Map.Entry)iter.next();
			        PartyData party = (PartyData)entry.getKey();
			        Channel channel = (Channel)((Map<String, Channel>)entry.getValue()).values().iterator().next();                 

			        if(((SocketPartyData)party).getPort()==8000)
			        {
			        	file_name = (String)channel.receive();
				        array = (byte[]) channel.receive();

				        if(file_name!=null && !file_name.isEmpty() && array!=null)
				        {
				        	isReceived=true;
				        	System.out.println("Received file "+file_name);
				           	byteArrayToFile(array,file_name); 
				        }
	
	
		        		if(isReceived==true)
		        		{
		        			System.out.println("Do you want to participate in secret recovery?{Y/N}");
		        			char ans = scan.next().charAt(0);
		        			if(ans=='Y')
		        			{
		        				recoverFiles.add(file_name);
		        				totalFiles++;
		        			}
		        				
		        		}
			        }
			        else
			        {
				        file_name = (String)channel.receive();
				        

				        if(file_name.compareTo("N")!=0)
				        {
				        	recoverFiles.add(file_name);
				        	totalFiles++;
				        	array = (byte[]) channel.receive();
				        	System.out.println("Received file "+file_name);
				           	byteArrayToFile(array,file_name); 
				        }

			        }
	            	

				}
				System.out.println("Files participating in secret recovery are :");
				for(String s: recoverFiles)
					System.out.println(s);
				System.out.println("totalFiles : "+totalFiles);
			}
			
		}catch(EOFException e)
		{

		}
		catch(Exception e)
		{
			System.out.println(e);
		}

	}

private static void SecretRec(int totalFiles) throws Exception{

     //Secret Recovery
    //Secret Recovery
     //Input file
     String outputFileName="output";
     String fileExt = ".txt";
     FileInputStream inR[] = null;
     DataInputStream dataInR[] = null;
     File fileinR[] = null; 

     //Output files
     FileOutputStream outR = null;
     DataOutputStream dataOutR = null;
     File fileoutR = null;



    SecretRecovery secRecObj;
    Scanner scan = new Scanner(System.in);
    FieldElement xPointsToRecoverSecret[],sharesToRecoverSecret[];
    String secretRecoveryFileNumbersArray[]=new String[totalFiles];

//this is to get the file no. 
    for(int i=0;i<totalFiles;i++)
    {
        if(!recoverFiles.get(i).isEmpty())
        {
            String array[] = recoverFiles.get(i).split(".txt");
            String array2[] = array[0].split("output");
            secretRecoveryFileNumbersArray[i]=array2[1];            
        }
        
    }
        

    
    fileinR = new File[totalFiles];
    inR = new FileInputStream[totalFiles];
    dataInR = new DataInputStream[totalFiles];

    String filn = "final" +outputFileName + fileExt;
    fileoutR = new File(filn);
    outR = new FileOutputStream(fileoutR);
    dataOutR = new DataOutputStream(outR);

    

    for(int i=0;i<totalFiles;i++){
       
        fileinR[i] = new File(recoverFiles.get(i));
        inR[i] = new FileInputStream(fileinR[i]);
        dataInR[i] = new DataInputStream(inR[i]);   
    }   

   for(long l=0;l<fileinR[0].length();l++){
        xPointsToRecoverSecret = new CryptoPpGF2pow8Element[totalFiles];
        sharesToRecoverSecret = new CryptoPpGF2pow8Element[totalFiles];
        for(int i=0;i<secretRecoveryFileNumbersArray.length;i++){
            xPointsToRecoverSecret[i] = new CryptoPpGF2pow8Element((byte)Integer.parseInt(secretRecoveryFileNumbersArray[i]));
            sharesToRecoverSecret[i] = new CryptoPpGF2pow8Element((dataInR[i].readByte()));
        }
        secRecObj = new SecretRecovery(recoverFiles.size(),xPointsToRecoverSecret,sharesToRecoverSecret);
        CryptoPpGF2pow8Element result =(CryptoPpGF2pow8Element)secRecObj.recoverSecret();
        dataOutR.write(result.getElementValue());

    }

    System.out.println("Secret recovered is :"+filn);
}



}
