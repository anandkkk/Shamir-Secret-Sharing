#include "StdAfx.h"

// cryptopp includes
#include "cryptlib.h"
#include "gfpcrypt.h"
#include "osrng.h"
#include "gf256.h"
// local includes
#include "CryptoPpPolynomialGF2pow8.h"
#include "Utils.h"

#include "pch.h"
#include "polynomi.h"
#include "secblock.h"

#include <sstream>
#include <iostream>


using namespace CryptoPP;

unsigned char inversePolyGF(unsigned char gfelement,jlong ring){
        unsigned char prgfelement = gfelement ;
        unsigned char element = gfelement;
        while(gfelement!=((byte)1)){
          prgfelement = gfelement;
          gfelement = ((GF256 *) ring)->Multiply(gfelement,((unsigned char) element));
        }
    return prgfelement;
}


JNIEXPORT jbyteArray JNICALL Java_edu_biu_scapi_primitives_dlog_CryptoPpPolynomialGF2pow8_PrepareBulkPolynomialInterpolation
  (JNIEnv * env, jobject, jlong ring, jbyteArray x, jint n)
{

	int xlen = (env)->GetArrayLength(x);
	jbyte *xarray = (env)->GetByteArrayElements(x, NULL);

	jbyteArray warr = env->NewByteArray(n);
	jbyte w[n]; 

	for (int i=0; i<n; i++)
	{
		unsigned char t = ((GF256 *) ring)->One();
		
		for (int j=0; j<n; j++)
			if (i != j)
				t = ((GF256 *) ring)->Multiply(t, ((GF256 *) ring)->Subtract((unsigned char)xarray[i], (unsigned char)xarray[j]));

		w[i] = inversePolyGF(t,ring);
	}
	
	env->SetByteArrayRegion(warr, 0, n,w);	

	return warr;	
}
JNIEXPORT jbyteArray JNICALL Java_edu_biu_scapi_primitives_dlog_CryptoPpPolynomialGF2pow8_PrepareBulkPolynomialInterpolationAt
  (JNIEnv * env, jobject, jlong ring, jbyte x_position, jbyteArray xarray, jbyteArray warray, jint n)
{

	jbyteArray v = env->NewByteArray(n);
	jbyte varr[n];

	int xlen = (env)->GetArrayLength(xarray);
	jbyte *x = (env)->GetByteArrayElements(xarray, 0);

	int wlen = (env)->GetArrayLength(warray);
	jbyte *w = (env)->GetByteArrayElements(warray, 0);


	unsigned char a[2*n-1];
	unsigned int i;

	for (i=0; i<n; i++)
		a[n-1+i] = ((GF256 *) ring)->Subtract((unsigned char)x_position, (unsigned char)x[i]);

	for (i=n-1; i>1; i--)
		a[i-1] = ((GF256 *) ring)->Multiply(a[2*i], a[2*i-1]);

	a[0] = ((GF256 *) ring)->One();

	for (i=0; i<n-1; i++)
	{
		std::swap(a[2*i+1], a[2*i+2]);
		a[2*i+1] = ((GF256 *) ring)->Multiply(a[i], a[2*i+1]);
		a[2*i+2] = ((GF256 *) ring)->Multiply(a[i], a[2*i+2]);
	}

	for (i=0; i<n; i++){
		varr[i] = ((GF256 *) ring)->Multiply(a[n-1+i], (unsigned char)w[i]);
	}
	env->SetByteArrayRegion(v, 0, n,varr);	

	return v;	

}

JNIEXPORT jbyte JNICALL Java_edu_biu_scapi_primitives_dlog_CryptoPpPolynomialGF2pow8_BulkPolynomialInterpolateAt
  (JNIEnv * env, jobject, jlong ring, jbyteArray yarray, jbyteArray varray, jint n)
{

	int vlen = (env)->GetArrayLength(varray);
	jbyte *v = (env)->GetByteArrayElements(varray, 0); 

	int ylen = (env)->GetArrayLength(yarray);
	jbyte *y = (env)->GetByteArrayElements(yarray, 0);


	unsigned char result = ((GF256 *) ring)->One();

	for (int i=0; i<n; i++)
		((GF256 *) ring)->Accumulate(result, ((GF256 *) ring)->Multiply((unsigned char)y[i], (unsigned char)v[i]));

	return result;
}
