#include "StdAfx.h"

// cryptopp includes
#include "cryptlib.h"
#include "gfpcrypt.h"
#include "osrng.h"
#include "gf256.h"
// local includes
#include "CryptoPpGF2pow8.h"
#include "Utils.h"

using namespace CryptoPP;

/* function createDlogZp : This function creates a Dlog group over Zp and returns a pointer to the created Dlog.
 * param p				 : field size (prime)
 * param q				 : order of the group
 * param g				 : generator of the group
 * return			     : A pointer to the created Dlog.
 */

JNIEXPORT jlong JNICALL Java_edu_biu_scapi_primitives_dlog_CryptoPpGF2pow8_createFieldGfWithModulus
  (JNIEnv *, jobject, jbyte modulus){
	  	GF256* field = new GF256(( unsigned char)modulus);
	  	return (jlong)field;
  }

JNIEXPORT jbyte JNICALL Java_edu_biu_scapi_primitives_dlog_CryptoPpGF2pow8_add
  (JNIEnv *env, jobject, jlong field, jbyte element1, jbyte element2){
	  	unsigned char gf1element = element1;
	  	unsigned char gf2element = element2;
  	return (jbyte)((GF256 *) field)->Add(gf1element,gf2element); 
  }

JNIEXPORT jbyte JNICALL Java_edu_biu_scapi_primitives_dlog_CryptoPpGF2pow8_multiply
  (JNIEnv *, jobject, jlong field, jbyte element1, jbyte element2){
	  	unsigned char gf1element = element1;
	  	unsigned char gf2element = element2;
  	return (jbyte)((GF256 *) field)->Multiply(gf1element,gf2element); 
  }

unsigned char inverseGF(unsigned char gfelement,jlong field){
        unsigned char prgfelement = gfelement ;
        unsigned char element = gfelement;
        while(gfelement!=((byte)1)){
          prgfelement = gfelement;
          gfelement = ((GF256 *) field)->Multiply(gfelement,((unsigned char) element));
        }
    return prgfelement;
}

JNIEXPORT jbyte JNICALL Java_edu_biu_scapi_primitives_dlog_CryptoPpGF2pow8_multiplicativeInverse
  (JNIEnv *, jobject, jlong field, jbyte element){
  	  	unsigned char gfelement = element;
  return (jbyte)inverseGF(gfelement,field); 	
  }

JNIEXPORT jbyte JNICALL Java_edu_biu_scapi_primitives_dlog_CryptoPpGF2pow8_divide
  (JNIEnv *, jobject, jlong field, jbyte element1, jbyte element2){
  	  unsigned char gf1element = element1;
	  	unsigned char gf2element = element2;


  	return (jbyte)((GF256 *) field)->Multiply(gf1element,inverseGF(gf2element,field));
  }
