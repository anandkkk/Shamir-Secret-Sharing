package edu.biu.scapi.primitives.dlog;
import edu.biu.scapi.primitives.dlog.CryptoPpPolynomialGF2pow32;
import edu.biu.scapi.primitives.dlog.CryptoPpGF2pow32Element;
import edu.biu.scapi.primitives.dlog.GF2mElement;

import java.util.*;
import java.security.SecureRandom;
import java.math.BigInteger;


public class SecretRecovery{

		private int threshold;
		private FieldElement[] xVals;
		private FieldElement[] yVals;
		

		public SecretRecovery(int threshold,FieldElement[] xVals,FieldElement[] yVals){
			
			this.threshold = threshold;
			this.xVals = xVals;
			this.yVals = yVals;
		}

		/* For GF2^32 */
		private int[] getintArray(FieldElement[] vals){

			int[] intArray = null;
			if(vals instanceof CryptoPpGF2pow32Element[]){
				intArray = new int[vals.length];
				for(int i=0;i<vals.length;i++)
					intArray[i] = ((CryptoPpGF2pow32Element)vals[i]).getElementValue();
			}
			return intArray;			
		}

		private byte[] getbyteArray(FieldElement[] vals){

			byte[] byteArray = null;
			if(vals instanceof CryptoPpGF2pow8Element[]){
				byteArray = new byte[vals.length];
				for(int i=0;i<vals.length;i++)
					byteArray[i] = ((CryptoPpGF2pow8Element)vals[i]).getElementValue();
			}
			return byteArray;			
		}

		public FieldElement recoverSecret(){

			if((xVals instanceof CryptoPpGF2pow32Element[])&&(yVals instanceof CryptoPpGF2pow32Element[])&&(xVals.length == 												yVals.length)&&(yVals.length==threshold)){
				
				CryptoPpPolynomialGF2pow32 polyRestore = new CryptoPpPolynomialGF2pow32(getintArray(xVals),getintArray
															(yVals),threshold);
				CryptoPpGF2pow32Element result = (CryptoPpGF2pow32Element)polyRestore.findValueAtX(new 											CryptoPpGF2pow32Element(0));
				
				return result;
			}else if((xVals instanceof CryptoPpGF2pow8Element[])&&(yVals instanceof CryptoPpGF2pow8Element[])&&(xVals.length 											== yVals.length)&&(yVals.length==threshold)){

				CryptoPpPolynomialGF2pow8 polyRestore = new CryptoPpPolynomialGF2pow8(getbyteArray(xVals),getbyteArray
															(yVals),threshold);
				CryptoPpGF2pow8Element result = (CryptoPpGF2pow8Element)polyRestore.findValueAtX(new CryptoPpGF2pow8Element((byte)0));

				return result;

			}
			//else if()
			//else if()

			return null;
		}	
}
