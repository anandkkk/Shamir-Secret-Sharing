package edu.biu.scapi.primitives.dlog;

import java.io.Serializable;

public interface FieldElementSendableData extends Serializable {

}
