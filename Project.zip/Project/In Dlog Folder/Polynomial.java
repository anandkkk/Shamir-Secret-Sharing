package edu.biu.scapi.primitives.dlog;
import edu.biu.scapi.primitives.dlog.Field;
import edu.biu.scapi.primitives.dlog.FieldElement;

/* Polynomial based on the concept of Langrange Polynomial Interpolation */

public interface Polynomial extends Field{

	/* values for array of x points */
	public FieldElement[] findValuesAtXPoints(FieldElement[] xpoints);
	
	/* value for of one point */
	public FieldElement findValueAtX(FieldElement x);

}
