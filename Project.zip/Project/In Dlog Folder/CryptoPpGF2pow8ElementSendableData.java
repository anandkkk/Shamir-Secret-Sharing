package edu.biu.scapi.primitives.dlog;
import edu.biu.scapi.primitives.dlog.GF2mElementSendableData;

public class CryptoPpGF2pow8ElementSendableData implements GF2mElementSendableData {

	private static final long serialVersionUID = -4297988366522300059L;

	byte x;

	public CryptoPpGF2pow8ElementSendableData(byte x) {
		super();
		this.x = x;
	}

	public byte getX() {
		return x;
	}

	@Override
	public String toString() {
		return "GF2pow32ElementSendableData [x=" + x + "]";
	}
	

}
