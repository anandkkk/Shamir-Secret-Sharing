package edu.biu.scapi.primitives.dlog;

import edu.biu.scapi.primitives.dlog.GF2m;
import edu.biu.scapi.primitives.dlog.CryptoPpGF2pow8Element;
import edu.biu.scapi.primitives.dlog.GF2mElement;
import edu.biu.scapi.primitives.dlog.FieldElement;


/**
 * This class implements a field over Galois Field with 8 bit utilizing Crypto++'s implementation.
 * It uses JNI technology to call Crypto++'s native code.
 */

public class CryptoPpGF2pow8 implements GF2m {

	protected long pointerToField = 0; // pointer to the native field for the GF 32 functionality */


	private native long createFieldGfWithModulus(byte modulus);
	private native byte add(long field,byte element1, byte element2);
	private native byte multiply(long field,byte element1, byte element2);
	private native byte multiplicativeInverse(long field,byte element);
	private native byte divide(long field,byte element1, byte element2);

	private CryptoPpGF2pow8Element modulus;
	

	public CryptoPpGF2pow8() {
		// Default Modulus - 0x0000008D => x^8 + x^1 + 1
		// byte Modulus for GF256 
		pointerToField = createFieldGfWithModulus((byte)27);
		modulus = new CryptoPpGF2pow8Element((byte)27);
	}

	/* Do not use unless modulus is irreducible polynomail */

	public CryptoPpGF2pow8(byte mod) throws Exception {

		pointerToField = createFieldGfWithModulus(mod);
		modulus = new CryptoPpGF2pow8Element(mod);
	}
	
	public int getPrime(){
		//Galois Field of type 2^32 hence prime number used is 2
		return 2;	
	}
	
	public int getExponent(){
		//Current Implementation is for 32 bits
		return 8;	
	}
	
	public GF2mElement getIrreducibleModulus(){
		return modulus;
	}

	public String getFieldType(){
		return "Galois Field - GF(2^8)";
	}

	public FieldElement add(FieldElement element1, FieldElement element2) throws Exception{

		if(!(element1 instanceof CryptoPpGF2pow8Element) || !(element2 instanceof CryptoPpGF2pow8Element))
			throw new IllegalArgumentException("element type doesn't match the field type");
		byte result;
		result = add(pointerToField,((CryptoPpGF2pow8Element)element1).getElementValue(),((CryptoPpGF2pow8Element)element2).getElementValue());
		
		return new CryptoPpGF2pow8Element(result);
	
	}

	public FieldElement subtract(FieldElement element1, FieldElement element2) throws Exception{
			// Since Mod2 on polynomial addition is same as addition using the same function

		if(!(element1 instanceof CryptoPpGF2pow8Element) || !(element2 instanceof CryptoPpGF2pow8Element))
			throw new IllegalArgumentException("element type doesn't match the field type");

		byte result;
		result = add(pointerToField,((CryptoPpGF2pow8Element)element1).getElementValue(),((CryptoPpGF2pow8Element)element2).getElementValue());
		
		return new CryptoPpGF2pow8Element(result);
	}

	public FieldElement multiply(FieldElement element1, FieldElement element2) throws Exception{
		if(!(element1 instanceof CryptoPpGF2pow8Element) || !(element2 instanceof CryptoPpGF2pow8Element))
			throw new IllegalArgumentException("element type doesn't match the field type");

		byte result;
		result = multiply(pointerToField,((CryptoPpGF2pow8Element)element1).getElementValue(),((CryptoPpGF2pow8Element)element2).getElementValue());	
		return new CryptoPpGF2pow8Element(result);
	}

	public FieldElement divide(FieldElement element1, FieldElement element2) throws Exception{

		if(!(element1 instanceof CryptoPpGF2pow8Element) || !(element2 instanceof CryptoPpGF2pow8Element))
			throw new IllegalArgumentException("element type doesn't match the field type");

			byte result = divide(pointerToField,((CryptoPpGF2pow8Element)element1).getElementValue(),((CryptoPpGF2pow8Element)element2).getElementValue());	
			return new CryptoPpGF2pow8Element(result);
	}

	public FieldElement multiplicativeInverse(FieldElement element) throws Exception{
		if(!(element instanceof CryptoPpGF2pow8Element))
			throw new IllegalArgumentException("element type doesn't match the field type");

		byte result = multiplicativeInverse(pointerToField, ((CryptoPpGF2pow8Element)element).getElementValue());	
		return new CryptoPpGF2pow8Element(result);
	}

	public FieldElement additiveInverse(FieldElement element) throws Exception{

		if(!(element instanceof CryptoPpGF2pow8Element))
			throw new IllegalArgumentException("element type doesn't match the field type");

		return element;
	}

	public FieldElement additiveIdentity() throws Exception{
		return new CryptoPpGF2pow8Element((byte)0);	
	}
	
	public FieldElement multiplicativeIdentity() throws Exception{	
		return new CryptoPpGF2pow8Element((byte)1);	
	}

// upload CryptoPP library
	static {
		System.loadLibrary("CryptoPPJavaInterface");
	}
	
}
