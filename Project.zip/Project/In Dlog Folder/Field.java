package edu.biu.scapi.primitives.dlog;
import edu.biu.scapi.primitives.dlog.FieldElement;

/**
 * This class implements a field over Galois Field with 32 bit utilizing Crypto++'s implementation.
 * It uses JNI technology to call Crypto++'s native code.
 */

public interface Field {

	//Finite field is always of the type p^n

	// Order of the field would be p^n

	// The prime order of the field
	public int getPrime();

	// Exponent of the field
	public int getExponent();

	//Field Type
	public String getFieldType();

	public FieldElement add(FieldElement element1, FieldElement element2) throws Exception;
	public FieldElement subtract(FieldElement element1, FieldElement element2) throws Exception;
	public FieldElement multiply(FieldElement element1, FieldElement element2) throws Exception;
	public FieldElement divide(FieldElement element1, FieldElement element2) throws Exception;
	public FieldElement additiveInverse(FieldElement element) throws Exception;
	public FieldElement multiplicativeInverse(FieldElement element) throws Exception;
	public FieldElement additiveIdentity() throws Exception;
	public FieldElement multiplicativeIdentity() throws Exception;
}
