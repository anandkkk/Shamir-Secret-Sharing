package edu.biu.scapi.primitives.dlog;

public interface GF2mElement extends GFElement{

	
}
