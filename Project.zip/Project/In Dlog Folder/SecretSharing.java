package edu.biu.scapi.primitives.dlog;
import edu.biu.scapi.primitives.dlog.CryptoPpPolynomialGF2pow32;
import edu.biu.scapi.primitives.dlog.CryptoPpGF2pow32Element;
import edu.biu.scapi.primitives.dlog.GF2mElement;
import edu.biu.scapi.primitives.dlog.PolynomialGF2m;
import edu.biu.scapi.primitives.dlog.FieldElement;

import java.util.*;
import java.security.SecureRandom;
import java.math.BigInteger;

public class SecretSharing{

		/* Shares, Threshold & Secret */

		private int threshold;
		private FieldElement secret;

		private SecureRandom random;

		private PolynomialGF2m polynomial;
		private GF2mElement[] xpts;

		/* GF2pow32 */
		private int xIntVals[];
		private	int yIntVals[];

		/* GF2pow8 */
		private byte xByteVals[];
		private byte yByteVals[];


		//Secret sharing for all field types
		public SecretSharing(int threshold,FieldElement secret){

			this.threshold = threshold;
			this.secret = secret;

			this.random = new SecureRandom();

			if(secret instanceof CryptoPpGF2pow8Element)
				this.byteGF2pow8(secret);

			if(secret instanceof CryptoPpGF2pow32Element)
				this.intGF2pow32(secret);


			this.createPolynomial(secret);
			//this.xpts = null;
			
		}

		public void setPoints(FieldElement xPoints[]){


			this.convertToCryptoPpGF2mElementArray(xPoints);
			
		}

		private void convertToCryptoPpGF2mElementArray(FieldElement xPoints[]){



			if(xPoints instanceof CryptoPpGF2pow32Element[]){
			this.xpts = new CryptoPpGF2pow32Element[xPoints.length];
				for(int i=0;i<xPoints.length;i++){
					xpts[i] = (CryptoPpGF2pow32Element)xPoints[i];
				}
			}else if(xPoints instanceof CryptoPpGF2pow8Element[]){
			this.xpts = new CryptoPpGF2pow8Element[xPoints.length];
				for(int i=0;i<xPoints.length;i++){
					xpts[i] = (CryptoPpGF2pow8Element)xPoints[i];
				}
			}

		}

		
		private boolean inArray(int n,int lim,int[] intArray){
			
			for(int i=0; i < lim;i++){
				if(n==intArray[i])
					return true;
			}
			return false;
		}

		private void intGF2pow32(FieldElement secret){
		
			xIntVals = new int[threshold];
			yIntVals = new int[threshold];
			
			xIntVals[0] = 0;
			yIntVals[0] = ((CryptoPpGF2pow32Element)secret).getElementValue();
			
			for(int i=1;i<threshold;i++){
				do{				
					byte[] xpnt = new byte[4];
					byte[] ypnt = new byte[4];
				
					random.nextBytes(xpnt);
					random.nextBytes(ypnt);
				
					xIntVals[i] = (new BigInteger(xpnt)).intValue();
					yIntVals[i] = (new BigInteger(ypnt)).intValue();

				}while(inArray(xIntVals[i],i,xIntVals)||inArray(yIntVals[i],i,yIntVals));
			}

		}

		private boolean inBArray(byte n,int lim,byte[] btArray){
			
			for(int i=0; i < lim;i++){
				if(n==btArray[i])
					return true;
			}
			return false;
		}


		private void byteGF2pow8(FieldElement secret){
				
			xByteVals = new byte[threshold];
			yByteVals = new byte[threshold];
		
			/* Threshold x vals */
			/* Threshold y vals */
			xByteVals[0] = (byte)0;
			yByteVals[0] = ((CryptoPpGF2pow8Element)secret).getElementValue();

			for(int i=1;i<threshold;i++){
				do{
					byte[] xpnt = new byte[1];
					byte[] ypnt = new byte[1];
					random.nextBytes(xpnt);
					random.nextBytes(ypnt);
					xByteVals[i] = xpnt[0];
					yByteVals[i] = ypnt[0];
				}while(inBArray(xByteVals[i],i,xByteVals)||inBArray(yByteVals[i],i,yByteVals));
			}

		}

		private void createPolynomial(FieldElement secret){

			if(secret instanceof CryptoPpGF2pow32Element){
				this.polynomial = new CryptoPpPolynomialGF2pow32(xIntVals,yIntVals,threshold);
			}else if(secret instanceof CryptoPpGF2pow8Element){
				this.polynomial = new CryptoPpPolynomialGF2pow8(xByteVals,yByteVals,threshold);
			}

		}

		public FieldElement getSecret(){
			return this.secret;
		}

		public int getThreshold(){
			return this.threshold;
		}

		public void setSecret(FieldElement secret){

			this.secret = secret;

			if(secret instanceof CryptoPpGF2pow8Element)
				this.byteGF2pow8(secret);

			if(secret instanceof CryptoPpGF2pow32Element)
				this.intGF2pow32(secret);

			this.createPolynomial(secret);	

		}

		public void setThreshold(int threshold){

			this.threshold = threshold;

			if(secret instanceof CryptoPpGF2pow8Element)
				this.byteGF2pow8(secret);

			if(secret instanceof CryptoPpGF2pow32Element)
				this.intGF2pow32(secret);
			
			this.createPolynomial(secret);
		}


		//Secret sharing for all field types
		public FieldElement[] splitShares(){

			if((this.xpts instanceof CryptoPpGF2pow32Element[])&&(this.secret instanceof CryptoPpGF2pow32Element)){
				/* Shares to be sent */
				GF2mElement shares[] = new CryptoPpGF2pow32Element[xpts.length];
				shares = ((CryptoPpPolynomialGF2pow32)this.polynomial).findValuesAtXPoints(xpts);
				return shares;
			}else if((this.xpts instanceof CryptoPpGF2pow8Element[])&&(this.secret instanceof CryptoPpGF2pow8Element)){
				/* Shares to be sent */
				GF2mElement shares[] = new CryptoPpGF2pow8Element[xpts.length];	
				shares = ((CryptoPpPolynomialGF2pow8)this.polynomial).findValuesAtXPoints(xpts);
				return shares;
			}

			return null;
		} 

		//Secret
}
