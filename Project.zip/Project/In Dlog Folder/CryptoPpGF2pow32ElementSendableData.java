package edu.biu.scapi.primitives.dlog;
import edu.biu.scapi.primitives.dlog.GF2mElementSendableData;

public class CryptoPpGF2pow32ElementSendableData implements GF2mElementSendableData {

	private static final long serialVersionUID = -4297988366522380059L;

	int x;

	public CryptoPpGF2pow32ElementSendableData(int x) {
		super();
		this.x = x;
	}

	public int getX() {
		return x;
	}

	@Override
	public String toString() {
		return "GF2pow32ElementSendableData [x=" + x + "]";
	}
	

}
