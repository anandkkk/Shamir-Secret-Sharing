package edu.biu.scapi.primitives.dlog;
import edu.biu.scapi.primitives.dlog.GF2m;
import edu.biu.scapi.primitives.dlog.GF2mElement;

/* Polynomial on GF2m based on the concept of Langrange Polynomial Interpolation */

public interface PolynomialGF2m extends GF2m{

	/* values for array of x points */
	public GF2mElement[] findValuesAtXPoints(GF2mElement[] xpoints);
	
	/* value for of one point */
	public GF2mElement findValueAtX(GF2mElement x);
		
}
