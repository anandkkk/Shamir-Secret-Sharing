package edu.biu.scapi.primitives.dlog;
import edu.biu.scapi.primitives.dlog.PolynomialGF2m;
import edu.biu.scapi.primitives.dlog.CryptoPpGF2pow32Element;
import edu.biu.scapi.primitives.dlog.GF2mElement;
import edu.biu.scapi.primitives.dlog.CryptoPpGF2pow32;


/* Polynomial based on the concept of Langrange Polynomial Interpolation */

public class CryptoPpPolynomialGF2pow32 extends CryptoPpGF2pow32 implements PolynomialGF2m {
	

	/* Polynomial is based on the fact that the values at different points is known 
		and we are trying to find values at other points */

	
	private int[] xVals;
	private int[] yVals;
	private int[] polyCoeffs;
	private int degree;

	/* Native code to send to cryptopp */

	private native int[] PrepareBulkPolynomialInterpolation(long ring,int x[], int n);
	private native int[] PrepareBulkPolynomialInterpolationAt(long ring,int x_position,int x[],int w[],int n);
	private native int BulkPolynomialInterpolateAt(long ring,int y[],int v[],int n);
	
	/* x,y points and degree of the polynomial */

	public CryptoPpPolynomialGF2pow32(int[] x,int[] y,int n){
		super();
		degree = n;
		xVals = x;
		yVals = y;
		polyCoeffs = PrepareBulkPolynomialInterpolation(pointerToField,xVals,n); 

	}
	
	/* values for array of x points */
	public GF2mElement[] findValuesAtXPoints(GF2mElement[] xpoints)
	{
		CryptoPpGF2pow32Element [] ypoints = new CryptoPpGF2pow32Element[xpoints.length];
		for(int i=0; i<xpoints.length;i++){
			
			int[] v = PrepareBulkPolynomialInterpolationAt(pointerToField,((CryptoPpGF2pow32Element)xpoints[i]).getElementValue(),xVals,polyCoeffs,degree);
			ypoints[i] = new CryptoPpGF2pow32Element(BulkPolynomialInterpolateAt(pointerToField,yVals,v,degree));
		}
		return ypoints;
	}
	/* value for of one point */
	public GF2mElement findValueAtX(GF2mElement x)
	{
		int[] v = PrepareBulkPolynomialInterpolationAt(pointerToField,((CryptoPpGF2pow32Element)x).getElementValue(),xVals,polyCoeffs,degree);
		return new CryptoPpGF2pow32Element (BulkPolynomialInterpolateAt(pointerToField,yVals,v,degree));
	}

	static {
		System.loadLibrary("CryptoPPJavaInterface");
	}

}
