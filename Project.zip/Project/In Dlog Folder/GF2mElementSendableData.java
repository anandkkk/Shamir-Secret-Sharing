package edu.biu.scapi.primitives.dlog;

public interface GF2mElementSendableData extends GFElementSendableData {

	

}
