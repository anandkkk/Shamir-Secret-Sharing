import edu.biu.scapi.primitives.dlog.CryptoPpGF2pow8;
import edu.biu.scapi.primitives.dlog.CryptoPpGF2pow8Element;
import java.util.*;

public class DlogExampleGaloisField8 {

    public static void main(String[] args) throws Exception {
	Scanner sc = new Scanner(System.in);
	int a = sc.nextInt();
	int b = sc.nextInt();        

	CryptoPpGF2pow8 test = new CryptoPpGF2pow8();
	CryptoPpGF2pow8Element ael = new CryptoPpGF2pow8Element((byte)a);
	CryptoPpGF2pow8Element bel = new CryptoPpGF2pow8Element((byte)b);
	System.out.println("Add - "+((CryptoPpGF2pow8Element)test.add(ael,bel)).getElementValue());
	System.out.println("Subtract - " + ((CryptoPpGF2pow8Element)test.subtract(ael,bel)).getElementValue());

	System.out.println("Multiply - " + ((CryptoPpGF2pow8Element)test.multiply(ael,bel)).getElementValue());
	System.out.println("Multiplicative Inverse - " + ((CryptoPpGF2pow8Element)test.multiplicativeInverse(ael)).getElementValue());
	System.out.println("Divide - " + ((CryptoPpGF2pow8Element)test.divide(ael,bel)).getElementValue());
	
    }

}
