import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

public class SecretSharingFile {
    public static void main(String[] args) throws IOException {

        
    	// Splitting the Shares

        FileInputStream in = null;
        FileOutputStream[] out = null;
        int nShares = 10;
		int threshold=7;

        String fileExt = ".txt";
        String inputFileName = "input";

        String inputFile = inputFileName + fileExt;

        String[] outPutFile = new String[nShares];

        String outFileName = "output";

        for(int i=0;i<nShares;i++){

        	outPutFile[i] =  outFileName + Integer.toString(i+1) + fileExt;

        }



        try {

	            in = new FileInputStream(inputFile);
	            out = new FileOutputStream[nShares];

	            for(int i=0;i<nShares;i++){
					out[i] = new FileOutputStream(outPutFile[i]);
	            }

	            int c;

	            //create secret sharing object and create points - participant id's

				FieldElement secret = new CryptoPpGF2pow8Element(0);
				
				SecretSharing secObj = new SecretSharing(threshold,secret);

				FieldElement shares[] = new CryptoPpGF2pow8Element[nShares];

				for(int i=0;i<nShares;i++){
					
					xPoints[i] = new CryptoPpGF2pow8Element((byte)(i+1));
				}
			
				secObj.setPoints(xPoints);



	            while ((c = in.read()) != -1) {

	            	//Call splitShare and set the set secret

	            	secret = CryptoPpGF2pow8Element(byte)c);

	            	secObj.setSecret(secret);

	            	shares = secObj.splitShares();

	            	//For loop write to individual shares	
	            	for(int i=0;i<nShares;i++)
	                	out[i].write((int)((CryptoPpGF2pow8Element)shares[i]).getElementValue());
            }
        } finally {
            if (in != null) {
                in.close();
            }
            for (int i=0;i<nShares ; i++ ){
           	if (out[i] != null) {
            	    out[i].close();
            } 	
            }
        }

        FileInputStream in = null;
        FileOutputStream[] out = null;
        


    }
}