import edu.biu.scapi.primitives.dlog.SecretSharing;
import edu.biu.scapi.primitives.dlog.SecretRecovery;
import edu.biu.scapi.primitives.dlog.SecretRecovery;
import edu.biu.scapi.primitives.dlog.CryptoPpPolynomialGF2pow8;
import edu.biu.scapi.primitives.dlog.CryptoPpGF2pow8Element;
import edu.biu.scapi.primitives.dlog.FieldElement;

import java.util.*;
import java.security.SecureRandom;
import java.math.BigInteger;

class PolynomialTest8{

	public static void main(String args[]) throws Exception{

		/* Shares, Threshold & Secret */

		// Sharing Part
	











		String s = "Hello";
		byte[] a = s.getBytes();
		
		

		int nShares = 10;
		FieldElement shares[] = new CryptoPpGF2pow8Element[nShares];

		FieldElement xPoints[] = new CryptoPpGF2pow8Element[nShares];


		int threshold=7;
		System.out.println(a[0]);

		FieldElement secret = new CryptoPpGF2pow8Element(a[0]);
		
		SecretSharing secObj = new SecretSharing(threshold,secret);

		for(int i=0;i<nShares;i++){
			
			xPoints[i] = new CryptoPpGF2pow8Element((byte)(i+1));
		}
		
		secObj.setPoints(xPoints);

//		for(int k=1;k<256;k++)
//		{

//		secret = new CryptoPpGF2pow8Element((byte)k);
		secObj.setSecret(secret);

		System.out.println(((CryptoPpGF2pow8Element)secret).getElementValue());

		shares = secObj.splitShares();					
			
		FieldElement u[] = new CryptoPpGF2pow8Element[threshold];
		FieldElement v[] = new CryptoPpGF2pow8Element[threshold];
		
		u[0] = 	(CryptoPpGF2pow8Element)xPoints[5];	
		v[0] = (CryptoPpGF2pow8Element)shares[5];

		u[1] = 	(CryptoPpGF2pow8Element)xPoints[0];	
		v[1] = (CryptoPpGF2pow8Element)shares[0];

		u[2] = 	(CryptoPpGF2pow8Element)xPoints[6];	
		v[2] = (CryptoPpGF2pow8Element)shares[6];


		u[3] = 	(CryptoPpGF2pow8Element)xPoints[9];	
		v[3] = (CryptoPpGF2pow8Element)shares[9];

		u[4] = 	(CryptoPpGF2pow8Element)xPoints[7];	
		v[4] = (CryptoPpGF2pow8Element)shares[7];

		u[5] = 	(CryptoPpGF2pow8Element)xPoints[2];	
		v[5] = (CryptoPpGF2pow8Element)shares[2];

		u[6] = 	(CryptoPpGF2pow8Element)xPoints[4];	
		v[6] = (CryptoPpGF2pow8Element)shares[4];

		SecretRecovery secRec = new SecretRecovery(threshold,u,v);
		
		CryptoPpGF2pow8Element result =(CryptoPpGF2pow8Element)secRec.recoverSecret();
		
		System.out.println("secret :" + result.getElementValue());
//		}		 
}
}
