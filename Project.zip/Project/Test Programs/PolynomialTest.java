import edu.biu.scapi.primitives.dlog.SecretSharing;
import edu.biu.scapi.primitives.dlog.SecretRecovery;
import edu.biu.scapi.primitives.dlog.SecretRecovery;
import edu.biu.scapi.primitives.dlog.CryptoPpPolynomialGF2pow32;
import edu.biu.scapi.primitives.dlog.CryptoPpGF2pow32Element;
import edu.biu.scapi.primitives.dlog.FieldElement;

import java.util.*;
import java.security.SecureRandom;
import java.math.BigInteger;

class PolynomialTest{

	public static void main(String args[]) throws Exception{

		/* Shares, Threshold & Secret */

		// Sharing Part


		int nShares = 10;
		FieldElement shares[] = new CryptoPpGF2pow32Element[nShares];
		CryptoPpGF2pow32Element xPoints[] = new CryptoPpGF2pow32Element[nShares];


		int threshold=7;
		String h = "Hell";
		
		byte[] b = h.getBytes();
		int sec = (new BigInteger(b)).intValue();
		System.out.println(sec+" "+b.length);
		CryptoPpGF2pow32Element secret = new CryptoPpGF2pow32Element(sec);

		SecretSharing secObj = new SecretSharing(threshold,secret);

		for(int i=0;i<nShares;i++){
			
			xPoints[i] = new CryptoPpGF2pow32Element(i+1);
		}

		secObj.setPoints(xPoints);

		secObj.setSecret(secret);

		shares = secObj.splitShares();

		for(int i=0;i<nShares;i++){
System.out.println("x:"+((CryptoPpGF2pow32Element)xPoints[i]).getElementValue()+" share:"+((CryptoPpGF2pow32Element)shares[i]).getElementValue());			
		}



		//Recovery part
					

			
		FieldElement u[] = new CryptoPpGF2pow32Element[threshold];
		FieldElement v[] = new CryptoPpGF2pow32Element[threshold];
		
		u[0] = 	(CryptoPpGF2pow32Element)xPoints[5];	
		v[0] = (CryptoPpGF2pow32Element)shares[5];

		u[1] = 	(CryptoPpGF2pow32Element)xPoints[0];	
		v[1] = (CryptoPpGF2pow32Element)shares[0];

		u[2] = 	(CryptoPpGF2pow32Element)xPoints[6];	
		v[2] = (CryptoPpGF2pow32Element)shares[6];


		u[3] = 	(CryptoPpGF2pow32Element)xPoints[9];	
		v[3] = (CryptoPpGF2pow32Element)shares[9];

		u[4] = 	(CryptoPpGF2pow32Element)xPoints[7];	
		v[4] = (CryptoPpGF2pow32Element)shares[7];

		u[5] = 	(CryptoPpGF2pow32Element)xPoints[2];	
		v[5] = (CryptoPpGF2pow32Element)shares[2];

		u[6] = 	(CryptoPpGF2pow32Element)xPoints[4];	
		v[6] = (CryptoPpGF2pow32Element)shares[4];

		SecretRecovery secRec = new SecretRecovery(threshold,u,v);
		
		CryptoPpGF2pow32Element result =(CryptoPpGF2pow32Element)secRec.recoverSecret();
		
		System.out.println("secret :" + result.getElementValue());		
		 
}
}
