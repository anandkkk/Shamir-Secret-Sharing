import edu.biu.scapi.primitives.dlog.CryptoPpGF2pow32;
import edu.biu.scapi.primitives.dlog.CryptoPpGF2pow32Element;
import java.util.*;
public class DlogExampleGaloisField {

    public static void main(String[] args) throws Exception {
	Scanner sc = new Scanner(System.in);
	int a = sc.nextInt();
	int b = sc.nextInt();
	
        CryptoPpGF2pow32 test = new CryptoPpGF2pow32();
	CryptoPpGF2pow32Element ael = new CryptoPpGF2pow32Element(a);
	CryptoPpGF2pow32Element bel = new CryptoPpGF2pow32Element(b);



	System.out.println("Add - "+((CryptoPpGF2pow32Element)test.add(ael,bel)).getElementValue());
	System.out.println("Subtract - " + ((CryptoPpGF2pow32Element)test.subtract(ael,bel)).getElementValue());
	System.out.println("Multiply - " + ((CryptoPpGF2pow32Element)test.multiply(ael,bel)).getElementValue());
	System.out.println("Multiplicative Inverse - " + ((CryptoPpGF2pow32Element)test.multiplicativeInverse(ael)).getElementValue());
	System.out.println("Divide - " + ((CryptoPpGF2pow32Element)test.divide(ael,bel)).getElementValue());

    }

}
