package edu.biu.scapi.primitives.dlog;
import edu.biu.scapi.primitives.dlog.FieldElementSendableData;

public interface FieldElement{

	public boolean isIdentity();

	public boolean isZero();

	public FieldElementSendableData generateSendableData();
	
}
