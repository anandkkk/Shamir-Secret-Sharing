package edu.biu.scapi.primitives.dlog;
import edu.biu.scapi.primitives.dlog.CryptoPpGF2pow32ElementSendableData;
public class CryptoPpGF2pow32Element implements GF2mElement{

	private int element;	
	
	
	public CryptoPpGF2pow32Element(int bitpoly){
		element = bitpoly;
	}
	public int getElementValue(){
		return element;
	}
	
	public boolean isIdentity(){
		if(this.element==1)
			return true;
		else
			return false;
	}

	public boolean isZero(){

		if(this.element==0)
			return true;
		else
			return false;

	}


	public FieldElementSendableData generateSendableData(){
		return new CryptoPpGF2pow32ElementSendableData(element);
	}	
}
