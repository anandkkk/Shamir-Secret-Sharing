package edu.biu.scapi.primitives.dlog;

public interface GFElement extends FieldElement{
	
}
