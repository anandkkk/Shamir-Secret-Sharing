package edu.biu.scapi.primitives.dlog;

public interface GFElementSendableData extends FieldElementSendableData {

}
