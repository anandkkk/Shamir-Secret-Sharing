package edu.biu.scapi.primitives.dlog;
import edu.biu.scapi.primitives.dlog.GF;
import edu.biu.scapi.primitives.dlog.GFElement;


/* Polynomial on GF based on the concept of Langrange Polynomial Interpolation */

public interface PolynomialGF extends GF{

	/* values for array of x points */
	public GFElement[] findValuesAtXPoints(GFElement[] xpoints);
	
	/* value for of one point */
	public GFElement findValueAtX(GFElement x);
	
}
