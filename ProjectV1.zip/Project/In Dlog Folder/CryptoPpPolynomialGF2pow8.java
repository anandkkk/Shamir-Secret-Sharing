package edu.biu.scapi.primitives.dlog;
import edu.biu.scapi.primitives.dlog.PolynomialGF2m;
import edu.biu.scapi.primitives.dlog.CryptoPpGF2pow8Element;
import edu.biu.scapi.primitives.dlog.GF2mElement;
import edu.biu.scapi.primitives.dlog.CryptoPpGF2pow8;


/* Polynomial based on the concept of Langrange Polynomial Interpolation */

public class CryptoPpPolynomialGF2pow8 extends CryptoPpGF2pow8 implements PolynomialGF2m {
	

	/* Polynomial is based on the fact that the values at different points is known 
		and we are trying to find values at other points */

	
	private byte[] xVals;
	private byte[] yVals;
	private byte[] polyCoeffs;
	private int degree;

	/* Native code to send to cryptopp */

	private native byte[] PrepareBulkPolynomialInterpolation(long ring,byte x[], int n);
	private native byte[] PrepareBulkPolynomialInterpolationAt(long ring,byte x_position,byte x[],byte w[],int n);
	private native byte BulkPolynomialInterpolateAt(long ring,byte y[],byte v[],int n);
	
	/* x,y points and degree of the polynomial */

	public CryptoPpPolynomialGF2pow8(byte[] x,byte[] y,int n){
		super();
		degree = n;
		xVals = x;
		yVals = y;
		polyCoeffs = PrepareBulkPolynomialInterpolation(pointerToField,xVals,n); 

	}
	
	/* values for array of x points */
	public GF2mElement[] findValuesAtXPoints(GF2mElement[] xpoints)
	{
		CryptoPpGF2pow8Element [] ypoints = new CryptoPpGF2pow8Element[xpoints.length];
		for(int i=0; i<xpoints.length;i++){
			
			byte[] v = PrepareBulkPolynomialInterpolationAt(pointerToField,((CryptoPpGF2pow8Element)xpoints[i]).getElementValue(),xVals,polyCoeffs,degree);
			ypoints[i] = new CryptoPpGF2pow8Element(BulkPolynomialInterpolateAt(pointerToField,yVals,v,degree));
		}
		return ypoints;

	}
	/* value for of one point */
	public GF2mElement findValueAtX(GF2mElement x)
	{
		byte[] v = PrepareBulkPolynomialInterpolationAt(pointerToField,((CryptoPpGF2pow8Element)x).getElementValue(),xVals,polyCoeffs,degree);
		return new CryptoPpGF2pow8Element (BulkPolynomialInterpolateAt(pointerToField,yVals,v,degree));
	}

	static {
		System.loadLibrary("CryptoPPJavaInterface");
	}

}
