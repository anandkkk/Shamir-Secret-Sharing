package edu.biu.scapi.primitives.dlog;

import edu.biu.scapi.primitives.dlog.GF2m;
import edu.biu.scapi.primitives.dlog.CryptoPpGF2pow32Element;
import edu.biu.scapi.primitives.dlog.GF2mElement;
import edu.biu.scapi.primitives.dlog.FieldElement;


/**
 * This class implements a field over Galois Field with 32 bit utilizing Crypto++'s implementation.
 * It uses JNI technology to call Crypto++'s native code.
 */

public class CryptoPpGF2pow32 implements GF2m {

	protected long pointerToField = 0; // pointer to the native field for the GF 32 functionality */

	private native long createFieldGf();
	private native long createFieldGfWithModulus(int modulus);
	private native int add(long field,int element1, int element2);
	private native int multiply(long field,int element1, int element2);
	private native int multiplicativeInverse(long field,int element);
	private native int divide(long field,int element1, int element2);
	private CryptoPpGF2pow32Element modulus;
	

	public CryptoPpGF2pow32() {
		// Default Modulus - 0x0000008D => x^32 + x^7 + x^3 + x^2 + 1
		pointerToField = createFieldGf();
		modulus = new CryptoPpGF2pow32Element(139);
	}

	public CryptoPpGF2pow32(int mod) throws Exception {
		// Validate if modulus is irreducible
		// First Check is 1 must be present
		if(mod%2==0){
			throw new Exception();
		}
		pointerToField = createFieldGfWithModulus(mod);

		modulus = new CryptoPpGF2pow32Element(mod);
	}
	
	public int getPrime(){
		//Galois Field of type 2^32 hence prime number used is 2
		return 2;	
	}
	
	public int getExponent(){
		//Current Implementation is for 32 bits
		return 32;	
	}
	
	public GF2mElement getIrreducibleModulus(){
		return modulus;
	}


	public String getFieldType(){
		return "Galois Field - GF(2^32)";
	}

	public FieldElement add(FieldElement element1, FieldElement element2) throws Exception{

		if(!(element1 instanceof CryptoPpGF2pow32Element) || !(element2 instanceof CryptoPpGF2pow32Element))
			throw new IllegalArgumentException("element type doesn't match the field type");
		int result;
		result = add(pointerToField,((CryptoPpGF2pow32Element)element1).getElementValue(),((CryptoPpGF2pow32Element)element2).getElementValue());
		
		return new CryptoPpGF2pow32Element(result);
	
	}

	public FieldElement subtract(FieldElement element1, FieldElement element2) throws Exception{
			// Since Mod2 on polynomial addition is same as addition using the same function

		if(!(element1 instanceof CryptoPpGF2pow32Element) || !(element2 instanceof CryptoPpGF2pow32Element))
			throw new IllegalArgumentException("element type doesn't match the field type");

		int result;
		result = add(pointerToField,((CryptoPpGF2pow32Element)element1).getElementValue(),((CryptoPpGF2pow32Element)element2).getElementValue());
		
		return new CryptoPpGF2pow32Element(result);
	}

	public FieldElement multiply(FieldElement element1, FieldElement element2) throws Exception{
		if(!(element1 instanceof CryptoPpGF2pow32Element) || !(element2 instanceof CryptoPpGF2pow32Element))
			throw new IllegalArgumentException("element type doesn't match the field type");

		int result;
		result = multiply(pointerToField,((CryptoPpGF2pow32Element)element1).getElementValue(),((CryptoPpGF2pow32Element)element2).getElementValue());	
		return new CryptoPpGF2pow32Element(result);
	}

	public FieldElement divide(FieldElement element1, FieldElement element2) throws Exception{

		if(!(element1 instanceof CryptoPpGF2pow32Element) || !(element2 instanceof CryptoPpGF2pow32Element))
			throw new IllegalArgumentException("element type doesn't match the field type");

			int result = divide(pointerToField,((CryptoPpGF2pow32Element)element1).getElementValue(),((CryptoPpGF2pow32Element)element2).getElementValue());	
			return new CryptoPpGF2pow32Element(result);
	}

	public FieldElement multiplicativeInverse(FieldElement element) throws Exception{
		if(!(element instanceof CryptoPpGF2pow32Element))
			throw new IllegalArgumentException("element type doesn't match the field type");

		int result = multiplicativeInverse(pointerToField, ((CryptoPpGF2pow32Element)element).getElementValue());	
		return new CryptoPpGF2pow32Element(result);
	}

	public FieldElement additiveInverse(FieldElement element) throws Exception{

		if(!(element instanceof CryptoPpGF2pow32Element))
			throw new IllegalArgumentException("element type doesn't match the field type");

		return element;
	}

	public FieldElement additiveIdentity() throws Exception{
		return new CryptoPpGF2pow32Element(0);	
	}
	
	public FieldElement multiplicativeIdentity() throws Exception{	
		return new CryptoPpGF2pow32Element(1);	
	}

// upload CryptoPP library
	static {
		System.loadLibrary("CryptoPPJavaInterface");
	}
	
}
