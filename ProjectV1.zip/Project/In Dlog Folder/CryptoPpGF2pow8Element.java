package edu.biu.scapi.primitives.dlog;
import edu.biu.scapi.primitives.dlog.CryptoPpGF2pow8ElementSendableData;
public class CryptoPpGF2pow8Element implements GF2mElement{

	private byte element;	
	
	public CryptoPpGF2pow8Element(){}
	
	public CryptoPpGF2pow8Element(byte bitpoly){
		element = bitpoly;
	}
	public byte getElementValue(){
		return element;
	}
	
	public boolean isIdentity(){
		if(this.element==((byte)1))
			return true;
		else
			return false;
	}

	public boolean isZero(){

		if(this.element==((byte)0))
			return true;
		else
			return false;
	}


	public FieldElementSendableData generateSendableData(){
		return new CryptoPpGF2pow8ElementSendableData(element);
	}	
}
