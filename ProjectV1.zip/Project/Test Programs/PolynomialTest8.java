import edu.biu.scapi.primitives.dlog.SecretSharing;
import edu.biu.scapi.primitives.dlog.SecretRecovery;
import edu.biu.scapi.primitives.dlog.SecretRecovery;
import edu.biu.scapi.primitives.dlog.CryptoPpPolynomialGF2pow8;
import edu.biu.scapi.primitives.dlog.CryptoPpGF2pow8Element;
import edu.biu.scapi.primitives.dlog.FieldElement;

import java.util.*;
import java.security.SecureRandom;
import java.math.BigInteger;

class PolynomialTest8
{

static	String inputString;
static	int nShares,threshold;
static	byte inputStringBytes[],secretRecByte[];


static	FieldElement shares[],xPoints[],u[],v[],sharesTotal[][];

static	SecretRecovery secRec;
static	SecretSharing secObj;

static	Scanner scan;


	public static void main(String args[]) throws Exception
	{


		scan = new Scanner(System.in);

		System.out.println("Enter t & n: ");
		threshold=scan.nextInt();		
		nShares=scan.nextInt();

		scan.nextLine();	
		
		System.out.println("Enter a string..");		
		inputString=scan.nextLine();		


		inputStringBytes = inputString.getBytes();
		secretRecByte=new byte[inputString.length()];
		
		
		shares = new CryptoPpGF2pow8Element[nShares];
		xPoints = new CryptoPpGF2pow8Element[nShares];

		sharesTotal = new CryptoPpGF2pow8Element[nShares][inputString.length()];
		



		for(int i=0;i<nShares;i++)
		{
			xPoints[i] = new CryptoPpGF2pow8Element((byte)(i+1));
			sharesTotal[i][0] = new CryptoPpGF2pow8Element();
		
		}

		u = new CryptoPpGF2pow8Element[threshold];
		v = new CryptoPpGF2pow8Element[threshold];

		//loop begin
		for(int l=0;l<inputStringBytes.length;l++)
		{			


			FieldElement secret = new CryptoPpGF2pow8Element(inputStringBytes[l]);
		
			secObj = new SecretSharing(threshold,secret);

		
			secObj.setPoints(xPoints);

			secObj.setSecret(secret);


			shares = secObj.splitShares();					
	
		
		
			for(int i=0;i<nShares;i++)
			{
				sharesTotal[i][l]=shares[i];

			}
	
				

	
		}
		//loop ended
		
		
		System.out.println("Shares generated are..");
		System.out.println("----------------***----------------");
		for(int i=0;i<nShares;i++)
		{
			System.out.print(i+". ");
			for(int j=0;j<inputString.length();j++)
				System.out.print(((CryptoPpGF2pow8Element)sharesTotal[i][j]).getElementValue()+"\t");
			System.out.println("\n\n");

		}
		System.out.println("----------------***----------------");

		System.out.println("enter atleast "+threshold+" shares. Share numbers (space-separated) from 0-"+(nShares-1)+" to get back the secret");
		
/*
	In recover secret, 
	if shares < threshold 
		then garbage value printed.
	This works only for (1,n), (2,n) scheme. When t>2, and if we give one share then cursor simply waits for input.
*/
		String num =scan.nextLine();
		
		String shareNums[]=num.split(" ");
		
		totalSecretRecovery(shareNums);


	}	


	



	 private static void totalSecretRecovery(String [] shareNums)
	 {

		for(int l=0;l<inputString.length();l++)
		{

			u = new CryptoPpGF2pow8Element[shareNums.length];
			v = new CryptoPpGF2pow8Element[shareNums.length];
	
		
			for(int i=0;i<shareNums.length;i++)
			{
				u[i] = 	(CryptoPpGF2pow8Element)xPoints[Integer.parseInt(shareNums[i])];	
				v[i] = (CryptoPpGF2pow8Element)sharesTotal[Integer.parseInt(shareNums[i])][l];
			}


			secRec = new SecretRecovery(threshold,u,v);
			CryptoPpGF2pow8Element result =(CryptoPpGF2pow8Element)secRec.recoverSecret();
						
				secretRecByte[l]=result.getElementValue();

		}

			String completeSecret=new String(secretRecByte);
			System.out.println("Complete Secret is :"+completeSecret);
	}

}
