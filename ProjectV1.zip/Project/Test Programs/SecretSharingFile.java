import edu.biu.scapi.primitives.dlog.SecretSharing;
import edu.biu.scapi.primitives.dlog.SecretRecovery;
import edu.biu.scapi.primitives.dlog.SecretRecovery;
import edu.biu.scapi.primitives.dlog.CryptoPpPolynomialGF2pow8;
import edu.biu.scapi.primitives.dlog.CryptoPpGF2pow8Element;
import edu.biu.scapi.primitives.dlog.FieldElement;

import java.util.*;
import java.security.SecureRandom;
import java.math.BigInteger;
import java.io.*;

class SecretSharingFile
{

static	String inputFileName="input",outputFileName="output",inputFile;
static String fileExt = ".txt";
static String[] outputFiles;
static File myInputfile;

static	int nShares,threshold;
static	byte ByteArrayOfFileCharacters[];


static	FieldElement shares[],xPoints[],xPointsToRecoverSecret[],sharesToRecoverSecret[],sharesMatrix[][],secret;

static	SecretRecovery secRecObj;
static	SecretSharing secSharObj;

static	Scanner scan;

static FileInputStream in = null;
static PrintWriter out[] = null;
static FileWriter fw[]=null;
static BufferedWriter bw[]=null;



	public static void main(String args[]) throws Exception
	{

		scan = new Scanner(System.in);

		System.out.println("Enter t & n: ");
		threshold=scan.nextInt();		
		nShares=scan.nextInt();
		scan.nextLine(); 

		outputFiles=new String[nShares+1];

		inputFile = inputFileName + fileExt;
		

		try{

			myInputfile = new File(inputFile);		
			in = new FileInputStream(inputFile);		
			fw = new FileWriter[nShares+1]; //nShares files and one output file
			bw = new BufferedWriter[nShares+1];
			out = new PrintWriter[nShares+1];

		
			for(int i=0;i<nShares+1;i++)
			{
				
				outputFiles[i] =  outputFileName + Integer.toString(i+1) + fileExt;		
				fw[i] = new FileWriter(outputFiles[i], true);
				bw[i] = new BufferedWriter(fw[i]);
				out[i] = new PrintWriter(bw[i]);

			}

				
		
			shares = new CryptoPpGF2pow8Element[nShares];
			xPoints = new CryptoPpGF2pow8Element[nShares];

			sharesMatrix = new CryptoPpGF2pow8Element[nShares][(int)myInputfile.length()];
		
			ByteArrayOfFileCharacters=new byte[(int)myInputfile.length()];

			for(int i=0;i<nShares;i++)
			{
				xPoints[i] = new CryptoPpGF2pow8Element((byte)(i+1));
				sharesMatrix[i][0] = new CryptoPpGF2pow8Element();
		
			}

			

			secret = new CryptoPpGF2pow8Element((byte)0);
			secSharObj = new SecretSharing(threshold,secret);

			secSharObj.setPoints(xPoints);

			int character;
			int l=0;
		        while ((character = in.read()) != -1) 
			{
				secret = new CryptoPpGF2pow8Element((byte)character);
		            	secSharObj.setSecret(secret);
		            	shares = secSharObj.splitShares();

				for(int i=0;i<nShares;i++)
					sharesMatrix[i][l]=shares[i];

				l++;
			}


		System.out.println("Shares generated are..");
		for(int i=0;i<nShares;i++)				
			System.out.println(outputFiles[i]);
	
				
	
		for(int i=0;i<nShares;i++)
		{
			for(int j=0;j<myInputfile.length();j++)
			{
				out[i].write(((CryptoPpGF2pow8Element)sharesMatrix[i][j]).getElementValue());		
			}
		}		
	
		System.out.println("enter atleast "+threshold+" shares. Share numbers (space-separated) from 1-"+nShares+" to get back the secret");

/*
	In recover secret, 
	if shares < threshold 
		then garbage value printed.
	This works only for (1,n), (2,n) scheme. When t>2, and if we give one share then cursor simply waits for input.
*/
		String secretRecoveryFileNumbers =scan.nextLine();
		
		String secretRecoveryFileNumbersArray[]=secretRecoveryFileNumbers.split(" ");
		
		totalSecretRecovery(secretRecoveryFileNumbersArray);

		//the last output file which contains recovered secret at nShares index
		System.out.println("Secret recovered is :"+outputFiles[nShares]);


	}
	finally 
		{
         		if (in != null) 
			{
        	    		in.close();
       		  	}
         		for (int i=0;i<nShares+1 ; i++ )
			{
		           	if (out[i] != null) 
				{
   	 	        	    out[i].close();
            			}	 	
      			}
	
		}	

}
	



	 private static void totalSecretRecovery(String [] secretRecoveryFileNumbersArray)
	 {

		for(int l=0;l<myInputfile.length();l++)
		{

			xPointsToRecoverSecret = new CryptoPpGF2pow8Element[secretRecoveryFileNumbersArray.length];
			sharesToRecoverSecret = new CryptoPpGF2pow8Element[secretRecoveryFileNumbersArray.length];
	
		
			for(int i=0;i<secretRecoveryFileNumbersArray.length;i++)
			{
				//we did -1 because files are numbered 1-N but the xPoints and shrares all start from 0th index 
				xPointsToRecoverSecret[i] =(CryptoPpGF2pow8Element)xPoints[Integer.parseInt(secretRecoveryFileNumbersArray[i])-1];	
				sharesToRecoverSecret[i] = (CryptoPpGF2pow8Element)sharesMatrix[Integer.parseInt(secretRecoveryFileNumbersArray[i])-1][l];
			}


			secRecObj = new SecretRecovery(threshold,xPointsToRecoverSecret,sharesToRecoverSecret);
			CryptoPpGF2pow8Element result =(CryptoPpGF2pow8Element)secRecObj.recoverSecret();
						
				ByteArrayOfFileCharacters[l]=result.getElementValue();

		}

			String completeSecret=new String(ByteArrayOfFileCharacters);
			out[nShares].write(completeSecret);
			//System.out.println("Complete Secret is :"+completeSecret);
	}

}
